brew tap homebrew/versions
brew install glfw3

brew install glew

brew install glm
